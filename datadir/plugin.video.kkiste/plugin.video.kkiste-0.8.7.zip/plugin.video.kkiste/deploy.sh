../deploy.sh "plugin.video.kkiste"
