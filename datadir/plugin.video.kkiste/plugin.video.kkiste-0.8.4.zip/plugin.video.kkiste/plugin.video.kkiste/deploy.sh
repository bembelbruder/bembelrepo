name="plugin.video.kkiste"
version=`grep -o -a -m 1 -h -r '[0-9]\.[0-9]\.[0-9]' addon.xml`

cp -r ../$name ../datadir/$name

cd ../datadir
zip -r $name/$name-${version}.zip $name/$name/
rm -r $name/$name

python addons_xml_generator.py
