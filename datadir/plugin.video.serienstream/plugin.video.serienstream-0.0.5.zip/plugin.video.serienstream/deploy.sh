../deploy.sh "plugin.video.serienstream"
