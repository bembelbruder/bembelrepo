def log_debug(msg):
    print "test"
    
def log_notice(msg):
    print "test"

def log_warning(msg):
    print "test"

def log_error(msg):
    print "test"

def log(msg):
    print "test"
