from lib.hoster.vivo import Vivo

v = Vivo()
print v.getVideoUrl("https://vivo.sx/525a10aec6")
