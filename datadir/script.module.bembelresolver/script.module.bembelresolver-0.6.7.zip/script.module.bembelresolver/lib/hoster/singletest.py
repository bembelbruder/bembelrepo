from hoster import powerwatch

print powerwatch.Powerwatch().getVideoUrl("http://powerwatch.pw/mcgksggf0tct")
