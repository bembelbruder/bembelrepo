from lib.hoster import vivo
print vivo.getVideoUrl("http://vivo.sx/2f06e20a67")
