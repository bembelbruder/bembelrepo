from hoster import vivo

f = vivo.Vivo()
print f.getVideoUrl("http://vivo.sx/83443bac32")
