from lib.hoster.vivo import Vivo

f = Vivo()

print f.getVideoUrl("http://vivo.sx/0a59b5cb49")
