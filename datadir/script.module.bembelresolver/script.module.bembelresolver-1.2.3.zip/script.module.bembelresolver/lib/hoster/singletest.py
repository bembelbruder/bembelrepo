from lib.hoster.rapidvideo import RapidVideo

x = RapidVideo()
link = x.getVideoUrl("http://www.rapidvideo.com/e/FJXD6P6EJ6")

print link
