import powerwatch

print powerwatch.getVideoUrl("http://powerwatch.pw/mcgksggf0tct")
