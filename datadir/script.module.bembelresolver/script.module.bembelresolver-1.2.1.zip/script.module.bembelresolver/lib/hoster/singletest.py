from lib.hoster.openload import Openload
x = Openload()
link = x.getVideoUrl("https://openload.co/f/hBnOckZOwgY")

print link