from lib.hoster.vidto import Vidto

f = Vidto()

print f.getVideoUrl("http://vidto.me/1p4580b723b0.html")
