from lib.hoster.powerwatch import Powerwatch

f = Powerwatch()

print f.getVideoUrl_ByOutsideUrl("https://bs.to/serie/Startrek-Deep-Space-Nine/4/26-Das-Urteil/PowerWatch-1")
