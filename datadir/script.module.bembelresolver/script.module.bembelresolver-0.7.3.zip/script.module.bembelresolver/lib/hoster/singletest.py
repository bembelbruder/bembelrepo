from hoster import videoweed

f = videoweed.Videoweed()
print f.getVideoUrl("http://www.videoweed.es/file/afdebf34e02d4")
