from lib.hoster.streamcloud import Streamcloud

f = Streamcloud()

print f.getVideoUrl("http://streamcloud.eu/350361odfo04/How.to.Get.Away.with.Murder.S01E12.German.DVDRip.x264-iNTENTiON.mkv.html")
