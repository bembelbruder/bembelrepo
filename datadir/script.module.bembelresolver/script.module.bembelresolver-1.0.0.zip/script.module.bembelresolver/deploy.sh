../deploy.sh script.module.bembelresolver
