from hoster import streamcloud

f = streamcloud()

print f.getVideoUrl("http://streamcloud.eu/njouloz1iynz/The_100_-_02x11_-_GerDub.avi.html")
