from lib.hoster import streamcloud

print streamcloud.getVideoUrl("http://streamcloud.eu/1ab7tj8gdi71/Street.Dance.Kids.Gemeinsam.sind.wir.Stars.2013.German.BDRiP.AC3.XViD-CRG.avi.html")
