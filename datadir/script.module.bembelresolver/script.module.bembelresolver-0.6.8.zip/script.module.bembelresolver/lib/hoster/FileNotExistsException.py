class FileNotExistsException(BaseException):
    pass 