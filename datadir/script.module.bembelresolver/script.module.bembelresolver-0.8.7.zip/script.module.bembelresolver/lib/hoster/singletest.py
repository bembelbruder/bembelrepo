from hoster import shared

f = shared.Shared()

print f.getVideoUrl("http://shared.sx/e2184bfcf3")
