from hoster import youwatch

f = youwatch.Youwatch()
print f.getVideoUrl("http://youwatch.org/1e3wnj0sddzv")
