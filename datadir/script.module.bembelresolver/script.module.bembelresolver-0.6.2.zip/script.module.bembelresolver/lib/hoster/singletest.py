import vivo

print vivo.getVideoUrl("http://vivo.sx/d7aa96688c")
