../deploy.sh "plugin.video.kinox"
