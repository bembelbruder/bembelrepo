name="plugin.video.kinox"
version=`grep -o -a -m 1 -h -r '[0-9]\.[0-9]\.[0-9]' addon.xml`

cp -r ../$name ../datadir/$name
zip -r ../datadir/$name/$name-${version}.zip ../datadir/$name/$name/
rm -r ../datadir/$name/$name
