../deploy.sh "plugin.video.serien"
