var=`grep -o -a -m 1 -h -r '[0-9]\.[0-9]\.[0-9]' addon.xml`
echo $var
