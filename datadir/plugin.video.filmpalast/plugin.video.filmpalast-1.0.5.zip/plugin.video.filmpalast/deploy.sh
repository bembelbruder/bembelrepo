../deploy.sh "plugin.video.filmpalast"
